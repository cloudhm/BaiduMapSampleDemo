//
//  ViewController.m
//  SunRain
//
//  Created by huangmin on 15/5/4.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(nonatomic,strong)UISegmentedControl*segmentedControl;
@property(nonatomic,strong)UISwitch*sw1;
@property(nonatomic,strong)UISwitch*sw2;
@property(nonatomic,strong)UISwitch*sw3;
@property(nonatomic,strong)UISwitch*sw4;
@property(nonatomic,strong)UISwitch*sw5;
@property(nonatomic,strong)UISwitch*sw6;
@property(nonatomic,strong)BMKMapStatus* mapStatus;
@property(nonatomic,strong)NSMutableArray*mapPoints;
@property(nonatomic,strong)UILabel*distanceLabel;
@property(nonatomic,assign)double distance;

@end
typedef enum  {普通图=0,卫星图} MapType;
@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"BaiduMap From Storyboard");
    self.distance=0.0;
    [self updateUI];
    
}
#pragma mark UiKit Init
-(void)updateUI{
    self.segmentedControl=[[UISegmentedControl alloc]initWithItems:@[@"普通图",@"卫星图"]];
    self.segmentedControl.frame=CGRectMake(20, 20, 100, 25);
    self.segmentedControl.tintColor=[UIColor blackColor];
    [self.view addSubview:self.segmentedControl];
    [self.view bringSubviewToFront:self.segmentedControl];
    [self.segmentedControl addTarget:self action:@selector(valueChanged:) forControlEvents:UIControlEventValueChanged];
    self.segmentedControl.selectedSegmentIndex=0;

    
    UILabel*l1=[[UILabel alloc]initWithFrame:CGRectMake(130, 25, 60, 25)];
    l1.textAlignment=NSTextAlignmentCenter;
    l1.text=@"3D图";
    [self.view addSubview:l1];
    self.sw1=[[UISwitch alloc]initWithFrame:CGRectMake(190, 20, 80, 30)];
    self.sw1.tag=1;
    [self.view addSubview:self.sw1];
    [self.sw1 addTarget:self action:@selector(changedSwitch:) forControlEvents:UIControlEventValueChanged];
    
    UILabel*l2=[[UILabel alloc]initWithFrame:CGRectMake(130, 60, 60, 25)];
    l2.textAlignment=NSTextAlignmentCenter;
    l2.text=@"交通图";
    [self.view addSubview:l2];
    self.sw2=[[UISwitch alloc]initWithFrame:CGRectMake(190, 55, 80, 30)];
    self.sw2.tag=2;
    [self.view addSubview:self.sw2];
    [self.sw2 addTarget:self action:@selector(changedSwitch:) forControlEvents:UIControlEventValueChanged];
    
    UILabel*l3=[[UILabel alloc]initWithFrame:CGRectMake(240, 25, 80, 25)];
    l3.textAlignment=NSTextAlignmentCenter;
    l3.text=@"比例尺";
    [self.view addSubview:l3];
    self.sw3=[[UISwitch alloc]initWithFrame:CGRectMake(320, 20, 80, 30)];
    self.sw3.tag=3;
    [self.view addSubview:self.sw3];
    [self.sw3 addTarget:self action:@selector(changedSwitch:) forControlEvents:UIControlEventValueChanged];
    
    UILabel*l4=[[UILabel alloc]initWithFrame:CGRectMake(240, 60, 80, 25)];
    l4.textAlignment=NSTextAlignmentCenter;
    l4.text=@"多点缩放";
    [self.view addSubview:l4];
    self.sw4=[[UISwitch alloc]initWithFrame:CGRectMake(320, 55, 80, 30)];
    self.sw4.tag=4;
    [self.view addSubview:self.sw4];
    [self.sw4 addTarget:self action:@selector(changedSwitch:) forControlEvents:UIControlEventValueChanged];
    
    UILabel*l5=[[UILabel alloc]initWithFrame:CGRectMake(5, 60, 70, 25)];
    l5.textAlignment=NSTextAlignmentCenter;
    l5.text=@"移动地图";
    [self.view addSubview:l5];
    self.sw5=[[UISwitch alloc]initWithFrame:CGRectMake(80, 55, 80, 30)];
    self.sw5.tag=5;
    [self.view addSubview:self.sw5];
    [self.sw5 addTarget:self action:@selector(changedSwitch:) forControlEvents:UIControlEventValueChanged];
    
    UILabel*l6=[[UILabel alloc]initWithFrame:CGRectMake(5, 95, 70, 25)];
    l6.textAlignment=NSTextAlignmentCenter;
    l6.text=@"手势中心";
    [self.view addSubview:l6];
    self.sw6=[[UISwitch alloc]initWithFrame:CGRectMake(80, 90, 80, 30)];
    self.sw6.tag=6;
    [self.view addSubview:self.sw6];
    [self.sw6 addTarget:self action:@selector(changedSwitch:) forControlEvents:UIControlEventValueChanged];
    
    UILabel*l7=[[UILabel alloc]initWithFrame:CGRectMake(5, 125, 70, 25)];
    l7.textAlignment=NSTextAlignmentCenter;
    l7.text=@"缩放级别";
    [self.view addSubview:l7];
    UITextField*tf1=[[UITextField alloc]initWithFrame:CGRectMake(80, 125, 50, 25)];
    tf1.placeholder=@"3-19";
    tf1.borderStyle=UITextBorderStyleRoundedRect;
    tf1.tag=7;
    [self.view addSubview:tf1];
    UIButton*btn1=[UIButton buttonWithType:UIButtonTypeSystem];
    btn1.frame=CGRectMake(135, 125, 50, 25);
    [btn1 setTitle:@"缩放" forState:UIControlStateNormal];
    btn1.tag=8;
    [btn1 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn1.layer.borderColor=[UIColor blueColor].CGColor;
    btn1.layer.cornerRadius=5;
    btn1.layer.borderWidth=1;
    [self.view addSubview:btn1];
    [btn1 addTarget:self action:@selector(startChanged:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel*l8=[[UILabel alloc]initWithFrame:CGRectMake(135, 95, 70, 25)];
    l8.textAlignment=NSTextAlignmentCenter;
    l8.text=@"旋转角度";
    [self.view addSubview:l8];
    UITextField*tf2=[[UITextField alloc]initWithFrame:CGRectMake(210, 95, 100, 25)];
    tf2.placeholder=@"-180~180";
    tf2.borderStyle=UITextBorderStyleRoundedRect;
    tf2.tag=9;
    [self.view addSubview:tf2];
    UIButton*btn2=[UIButton buttonWithType:UIButtonTypeSystem];
    btn2.frame=CGRectMake(315, 95, 50, 25);
    [btn2 setTitle:@"旋转" forState:UIControlStateNormal];
    btn2.tag=10;
    [btn2 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn2.layer.borderColor=[UIColor blueColor].CGColor;
    btn2.layer.cornerRadius=5;
    btn2.layer.borderWidth=1;
    [self.view addSubview:btn2];
    [btn2 addTarget:self action:@selector(startChanged:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel*l9=[[UILabel alloc]initWithFrame:CGRectMake(185, 125, 70, 25)];
    l9.textAlignment=NSTextAlignmentCenter;
    l9.text=@"俯视角度";
    [self.view addSubview:l9];
    UITextField*tf3=[[UITextField alloc]initWithFrame:CGRectMake(255, 125, 60, 25)];
    tf3.placeholder=@"-45~0";
    tf3.borderStyle=UITextBorderStyleRoundedRect;
    tf3.tag=11;
    [self.view addSubview:tf3];
    UIButton*btn3=[UIButton buttonWithType:UIButtonTypeSystem];
    btn3.frame=CGRectMake(320, 125, 50, 25);
    [btn3 setTitle:@"俯视" forState:UIControlStateNormal];
    btn3.tag=12;
    [btn3 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn3.layer.borderColor=[UIColor blueColor].CGColor;
    btn3.layer.cornerRadius=5;
    btn3.layer.borderWidth=1;
    [self.view addSubview:btn3];
    [btn3 addTarget:self action:@selector(startChanged:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton*btn4=[UIButton buttonWithType:UIButtonTypeSystem];
    btn4.frame=CGRectMake(5, 155, 120, 25);
    [btn4 setTitle:@"同时改变地图状态" forState:UIControlStateNormal];
    [btn4 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn4.tag=13;
    btn4.layer.borderColor=[UIColor greenColor].CGColor;
    btn4.layer.cornerRadius=5;
    btn4.layer.borderWidth=1;
    [self.view addSubview:btn4];
    [btn4 addTarget:self action:@selector(startChanged:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton*btn5=[UIButton buttonWithType:UIButtonTypeSystem];
    btn5.frame=CGRectMake(130, 155, 60, 25);
    [btn5 setTitle:@"截图" forState:UIControlStateNormal];
    [btn5 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn5.tag=14;
    btn5.layer.borderColor=[UIColor greenColor].CGColor;
    btn5.layer.cornerRadius=5;
    btn5.layer.borderWidth=1;
    [self.view addSubview:btn5];
    [btn5 addTarget:self action:@selector(startChanged:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton*btn6=[UIButton buttonWithType:UIButtonTypeSystem];
    btn6.frame=CGRectMake(200, 155, 80, 25);
    [btn6 setTitle:@"开始测距" forState:UIControlStateNormal];
    [btn6 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    btn6.tag=15;
    btn6.layer.borderColor=[UIColor greenColor].CGColor;
    btn6.layer.cornerRadius=5;
    btn6.layer.borderWidth=1;
    [self.view addSubview:btn6];
    [btn6 addTarget:self action:@selector(startChanged:) forControlEvents:UIControlEventTouchUpInside];
    
    self.distanceLabel=[[UILabel alloc]initWithFrame:CGRectMake(290, 155, 70, 25)];
    self.distanceLabel.text=@"";
    self.distanceLabel.textAlignment=NSTextAlignmentCenter;
    self.distanceLabel.adjustsFontSizeToFitWidth=YES;
    self.distanceLabel.textColor=[UIColor redColor];
    [self.view addSubview:self.distanceLabel];
    
    self.mapView.trafficEnabled=NO;//交通图开关
    self.mapView.rotateEnabled=NO;//旋转开关
    self.mapView.overlookEnabled=NO;//俯视开关
    self.mapView.zoomEnabledWithTap=NO;//多点缩放开关
    self.mapView.scrollEnabled=NO;//移动地图
    self.mapView.ChangeWithTouchPointCenterEnabled=NO;//手势中心点缩放和旋转地图
    
    UITapGestureRecognizer*tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tripleClick:)];//添加一个三连击手势
    tapGR.numberOfTapsRequired=3;
    [self.mapView addGestureRecognizer:tapGR];
}
#pragma mark Triple-Click Tap
-(void)tripleClick:(UITapGestureRecognizer*)gr{// 设置地图中心点在地图中的屏幕坐标位置
    CGPoint p=[gr locationInView:self.mapView];
    [self.mapView setMapCenterToScreenPt:p];
}
#pragma mark Button-Invoke Method
-(void)startChanged:(UIButton*)btn{
    UITextField*tf=nil;
    switch (btn.tag) {
        case 8:
        {
            tf=(UITextField*)[self.view viewWithTag:(btn.tag-1)];
            if (tf.text.floatValue>=3&&tf.text.floatValue<=19) {
                self.mapView.zoomLevel=tf.text.floatValue;
            }
        }
            break;
        case 10:
        {
            tf=(UITextField*)[self.view viewWithTag:(btn.tag-1)];
            if (tf.text.integerValue>=-180&&tf.text.integerValue<=180) {
                self.mapView.rotation=(int)tf.text.integerValue;
            }
        }
            break;
        case 12:
        {
            tf=(UITextField*)[self.view viewWithTag:(btn.tag-1)];
            if (tf.text.integerValue>=-45&&tf.text.integerValue<=0) {
                self.mapView.overlooking=(int)tf.text.integerValue;
            }
        }
            break;
        case 13:
        {
            if (!self.mapStatus) {
                self.mapStatus=[[BMKMapStatus alloc]init];
            }
            tf=(UITextField*)[self.view viewWithTag:7];
            self.mapStatus.fLevel=(tf.text.floatValue>=3&&tf.text.floatValue<=19)?tf.text.floatValue:13.0f;
            tf=(UITextField*)[self.view viewWithTag:9];
            self.mapStatus.fRotation=(tf.text.floatValue>=-180 && tf.text.floatValue<=180)?tf.text.floatValue:0.0f;
            tf=(UITextField*)[self.view viewWithTag:11];
            self.mapStatus.fOverlooking=(tf.text.floatValue>=-45&&tf.text.floatValue<=0)?tf.text.floatValue:0.0f;
            
            self.mapStatus.targetGeoPt = CLLocationCoordinate2DMake(39.914855,116.403882);
            [self.mapView setMapStatus:self.mapStatus withAnimation:YES withAnimationTime:6000];
        }
            break;
        case 14:
        {
            UIImageView*iv=[[UIImageView alloc]init];
            iv.image=[self.mapView takeSnapshot];
            
            UIImageWriteToSavedPhotosAlbum(iv.image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);//将截图写入相册
        }
            break;
        case 15:
        {
            if ([[btn titleForState:UIControlStateNormal]isEqualToString:@"结束测距"]) {
                [btn setTitle:@"开始测距" forState:UIControlStateNormal];
                [self.mapView removeOverlays:self.mapView.overlays];
                self.distanceLabel.text=@"";
                self.distance=0.0;
                [self.mapView removeAnnotations:self.mapView.annotations];
                [self.mapPoints removeAllObjects];
                self.mapPoints=nil;
            } else {
                [btn setTitle:@"结束测距" forState:UIControlStateNormal];
                self.mapPoints=[NSMutableArray array];
                self.distanceLabel.text=@"0米";
            }
        }
            
            break;
        default:
            break;
    }
}
#pragma mark BMKMapView Delegate-Method
-(void)mapView:(BMKMapView *)mapView onClickedMapBlank:(CLLocationCoordinate2D)coordinate{
    [self.mapView removeOverlays:self.mapView.overlays];//防止重复，每次进这个方法遍历前，都清空一下原来的覆盖物
    
    BMKPointAnnotation* ann=[[BMKPointAnnotation alloc]init];//每点击一个位置添加一个大头针
    CLLocationCoordinate2D coord;
    coord.latitude=coordinate.latitude;
    coord.longitude=coordinate.longitude;
    ann.coordinate=coord;
    [self.mapView addAnnotation:ann];
    
    if (self.mapPoints==nil) {
        return;
    }
    BMKMapPoint p=BMKMapPointForCoordinate(coordinate);
    CGPoint sysP=CGPointMake(p.x, p.y);
    NSValue* p_value=[NSValue valueWithCGPoint:sysP];
    [self.mapPoints addObject:p_value];
    NSLog(@"%@",self.mapPoints);
    if (self.mapPoints.count>1) {
        for (NSInteger index=0; index<self.mapPoints.count-1; index++) {
            
            BMKMapPoint pointFrom;
            BMKMapPoint pointTo;
            CGPoint p1=[[self.mapPoints objectAtIndex:index] CGPointValue];
            CGPoint p2=[[self.mapPoints objectAtIndex:index+1] CGPointValue];
            pointFrom = BMKMapPointMake(p1.x, p1.y);
            pointTo = BMKMapPointMake(p2.x, p2.y);
            
            if (index==self.mapPoints.count-2) {//每次遍历，总距离只加最后一段的长度
                CLLocationDistance meter;
                meter = BMKMetersBetweenMapPoints(pointFrom,pointTo);//计算每段路程距离
                self.distance+=meter;
            }
            
            
            
            CLLocationCoordinate2D coord1=BMKCoordinateForMapPoint(pointFrom);
            CLLocationCoordinate2D coord2=BMKCoordinateForMapPoint(pointTo);
            
            CLLocationCoordinate2D coors[2]={coord1,coord2};
            BMKPolyline* polyline=[BMKPolyline polylineWithCoordinates:coors count:2];
            [self.mapView addOverlay:polyline];
        }
        
        self.distanceLabel.text= self.distance<1000?
        [NSString stringWithFormat:@"%.0lf米",self.distance]:
        [NSString stringWithFormat:@"%.1lf公里",self.distance/1000];
//        NSLog(@"%ld",self.mapView.overlays.count);//验证覆盖物数量
    }
}
- (BMKOverlayView *)mapView:(BMKMapView *)mapView viewForOverlay:(id<BMKOverlay>)overlay
{
    if ([overlay isKindOfClass:[BMKPolyline class]]) {
        BMKPolylineView* polylineView = [[BMKPolylineView alloc]initWithOverlay:overlay];
        polylineView.strokeColor = [[UIColor blueColor]colorWithAlphaComponent:0.7];
        polylineView.lineWidth = 3.0;
        return polylineView;
    }
    return nil;
}
#pragma mark BMKAnnotationView
- (BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id <BMKAnnotation>)annotation {
    BMKAnnotationView *annotationView = (BMKAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"renameMark"];
    if (annotationView == nil) {
        annotationView = [[BMKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"renameMark"];
        
        annotationView.image=[UIImage imageNamed:@"mapapi.bundle/images/icon_center_point@2x.png"];
    }
    return annotationView;
}
#pragma mark Save Image To PhotosAlbum
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo{
    NSString*message=nil;
    if (!error) {
        message = @"成功保存到相册";
    } else {
        message = [error description];
    }
    UIAlertView*av=[[UIAlertView alloc]initWithTitle:message message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [av show];
}
#pragma mark Switch-Control
-(void)changedSwitch:(UISwitch*)sw{
    if (sw.tag==1) {//3D图
        if (sw.on) {
            self.mapView.rotation=90;
            self.mapView.overlooking=-45;
            self.mapView.compassPosition=CGPointMake(self.mapView.bounds.size.width-100, 25);//设置指南针显示位置
        } else {
            self.mapView.rotation=0;
            self.mapView.overlooking=0;
        }
    } else if (sw.tag==2) {//交通图
        self.mapView.trafficEnabled=sw.on;
    } else if (sw.tag==3) {//比例尺
        self.mapView.showMapScaleBar=sw.on;
        self.mapView.mapScaleBarPosition=CGPointMake(300, self.mapView.bounds.size.height-200);
    } else if (sw.tag==4) {//多点缩放开关
        self.mapView.zoomEnabledWithTap=sw.on;
    } else if (sw.tag==5) {//移动地图
        self.mapView.scrollEnabled=sw.on;
    } else if (sw.tag==6) {//手势中心点缩放和旋转地图
        self.mapView.ChangeWithTouchPointCenterEnabled=sw.on;
        self.mapView.rotateEnabled=sw.on;
    }
}
#pragma mark SegmentControl for Changing MapStatus
-(void)valueChanged:(UISegmentedControl*)seg{
    NSLog(@"%ld",seg.selectedSegmentIndex);
    switch (seg.selectedSegmentIndex) {
        case 普通图:
            self.mapView.mapType=BMKMapTypeStandard;///< 标准地图
            break;
        case 卫星图:
            self.mapView.mapType=BMKMapTypeSatellite;///< 卫星地图
            break;
        default:
            break;
    }
}
#pragma mark Other Memory Management
-(void)viewWillAppear:(BOOL)animated{
    [self.mapView viewWillAppear];
    self.mapView.delegate=self;
}
-(void)viewWillDisappear:(BOOL)animated{
    [self.mapView viewWillDisappear];
    self.mapView.delegate=nil;
}
-(void)dealloc{
    self.mapView=nil;
    self.mapStatus=nil;
    self.mapPoints=nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
