//
//  ViewController.h
//  SunRain
//
//  Created by huangmin on 15/5/4.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI/BMapKit.h>
@interface ViewController : UIViewController<BMKMapViewDelegate>

@property(nonatomic,weak)IBOutlet BMKMapView* mapView;

@end

